file = open("new.csv","r").read()
print(file)